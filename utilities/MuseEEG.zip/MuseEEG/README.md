Muse
====

Preconfigured scripts for the Muse EEG headset http://www.choosemuse.com/

Edit config.txt to change device name, and osc host + port. Should be able to double click and run as applications, if not give the command file's the correct permissions. eg.

chmod u+x run-muse-preset-A.command

- Preset A: 4 channel 220htz, accelerometer, battery/temp, at 60htz filter
- Preset B: 4 channel 220htz, accelerometer, battery/temp, with FFT at 60htz filter
- Preset C: 4 channel 220htz, accelerometer, battery/temp, at 50htz filter
- Preset D: 4 channel 220htz, accelerometer, battery/temp, with FFT at 50htz filter